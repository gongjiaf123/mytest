package com.mqiy.service;

import com.mqiy.model.Blog;

public interface BlogService {
	Blog getById(int id);
}
