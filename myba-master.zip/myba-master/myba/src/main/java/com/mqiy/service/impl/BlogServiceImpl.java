package com.mqiy.service.impl;

import com.mqiy.model.Blog;
import com.mqiy.service.BlogService;

public class BlogServiceImpl implements BlogService {

	@Override
	public Blog getById(int id) {
		return null;
	}

}
